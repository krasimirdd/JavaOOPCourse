package foodShortage;

public interface Person {
    String getName();
    String getAge();
}
