package foodShortage;

public interface Identifiable extends Person {
    String getId();
}
