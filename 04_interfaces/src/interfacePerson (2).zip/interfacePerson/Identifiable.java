package interfacePerson;

public interface Identifiable {
    String getId();

}
