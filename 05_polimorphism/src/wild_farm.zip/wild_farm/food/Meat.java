package wild_farm.food;

public class Meat extends Food{
    public Meat(Integer quantity) {
        super(quantity);
    }
}
