package wild_farm.animals;

import wild_farm.food.Food;

public class Zebra extends Mammal {

    public Zebra(String animalType, String animalName, Double animalWeight, String animalLiving) {
        super(animalType, animalName, animalWeight, animalLiving);
    }

    @Override
    public void makeSound() {
        System.out.println("Zs");
    }

    @Override
    public void eat(Food food) {
        if (food.getClass().getSimpleName().equals("Meat")) {
            System.out.println("Zebras are not eating that type of food!");
        } else {
            super.eat(food);
        }
    }
}
