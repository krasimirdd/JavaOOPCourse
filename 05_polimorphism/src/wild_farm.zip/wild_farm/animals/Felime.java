package wild_farm.animals;

public abstract class Felime extends Mammal {

    protected Felime( String animalType,String animalName, Double animalWeight, String animalLiving) {
        super( animalType,animalName, animalWeight, animalLiving);
    }
}
