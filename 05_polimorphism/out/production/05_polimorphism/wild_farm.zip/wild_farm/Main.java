package wild_farm;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String[] data = scanner.nextLine().split("\\s+");
        Food food = null;
        Animal animal = null;

        for (int i = 1; !data[0].equals("End"); i++) {

            switch (data[0]) {
                case "Cat":
                    animal =
                            new Cat(data[0], data[1], Double.parseDouble(data[2]), data[3], data[4]);
                    break;
                case "Tiger":
                    animal =
                            new Tiger(data[0], data[1], Double.parseDouble(data[2]), data[3]);
                    break;
                case "Zebra":
                    animal =
                            new Zebra(data[0], data[1], Double.parseDouble(data[2]), data[3]);
                    break;
                case "Mouse":
                    animal =
                            new Mouse(data[0], data[1], Double.parseDouble(data[2]), data[3]);
                    break;

                case "Vegetable":
                    food = new Vegetable(Integer.parseInt(data[1]));
                    break;

                case "Meat":
                    food = new Meat(Integer.parseInt(data[1]));
                    break;
            }

            if (i % 2 == 0) {
                animal.makeSound();
                animal.eat(food);
                System.out.println(animal.toString());
            }
            data = scanner.nextLine().split("\\s+");
        }
    }
}
