package wild_farm;

public class Tiger extends Felime {
    private String livingRegion;

    public Tiger(String animalType, String animalName, Double animalWeight, String animalLiving) {
        super(animalType, animalName, animalWeight, animalLiving);
        this.livingRegion = animalLiving;
    }

    @Override
    protected void makeSound() {
        System.out.println("ROAAR!!!");
    }

    @Override
    protected void eat(Food food) {
        if (food.getClass().getSimpleName().equals("Vegetable")) {
            System.out.println("Tigers are not eating that type of food!");
        } else {
            super.eat(food);
        }
    }
}
