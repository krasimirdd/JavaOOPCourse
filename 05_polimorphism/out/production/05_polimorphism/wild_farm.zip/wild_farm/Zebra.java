package wild_farm;

public class Zebra extends Mammal {

    public Zebra( String animalType,String animalName, Double animalWeight, String animalLiving) {
        super(animalType,animalName,  animalWeight, animalLiving);
    }

    @Override
    protected void makeSound() {
        System.out.println("Zs");
    }

    @Override
    protected void eat(Food food) {
        if (food.getClass().getSimpleName().equals("Meat")) {
            System.out.println("Zebras are not eating that type of food!");
        } else {
            super.eat(food);
        }
    }
}
