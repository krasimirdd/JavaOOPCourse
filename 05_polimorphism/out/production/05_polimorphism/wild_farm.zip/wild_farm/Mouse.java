package wild_farm;

public class Mouse extends Mammal {
    public Mouse(String animalType, String animalName, Double animalWeight, String animalLiving) {
        super(animalType, animalName, animalWeight, animalLiving);
    }

    @Override
    protected void eat(Food food) {
        if (food.getClass().getSimpleName().equals("Meat")) {
            System.out.println("Mice are not eating that type of food!");
        } else {
            super.eat(food);
        }
    }

    @Override
    protected void makeSound() {
        System.out.println("SQUEEEAAAK!");
    }
}
