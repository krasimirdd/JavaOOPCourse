package vehicles;

public interface Vehicle {

    public String drive(double distance);
    public void refuel(double liters);
}
