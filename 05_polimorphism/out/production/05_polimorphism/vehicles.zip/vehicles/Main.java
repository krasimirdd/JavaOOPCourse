package vehicles;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String[] s = scanner.nextLine().split(" ");
        Car car = new Car(Double.parseDouble(s[1]), Double.parseDouble(s[2]));


        s = scanner.nextLine().split(" ");
        Truck truck = new Truck(Double.parseDouble(s[1]), Double.parseDouble(s[2]));

        int n = Integer.parseInt(scanner.nextLine());

        while (n-- > 0) {
            s = scanner.nextLine().split(" ");

            switch (s[0]) {
                case "Drive":
                    if (s[1].equals("Car")) {
                        System.out.println(car.drive(Double.parseDouble(s[2])));
                    } else {
                        System.out.println(truck.drive(Double.parseDouble(s[2])));
                    }
                    break;

                case "Refuel":
                    if (s[1].equals("Car")) {
                        car.refuel(Double.parseDouble(s[2]));
                    } else {
                        truck.refuel(Double.parseDouble(s[2]));
                    }
                    break;
            }
        }

        System.out.println(car.toString());
        System.out.println(truck.toString());
    }
}
