package mankind;

public class Person {
}
