package traffic_lights;

public enum Light {
    RED,
    GREEN,
    YELLOW,
}
