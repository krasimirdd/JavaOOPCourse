package footbal_team_generator;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();

        List<Team> teams = new ArrayList<>();

        while (!"END".equals(input)) {
            Team team;
            String[] data = input.split(";");

            try {
                switch (data[0]) {

                    case "Team":
                        team = new Team(data[1]);
                        teams.add(team);
                        break;

                    case "Add":
                        boolean isTeamPresented = false;
                        for (Team t : teams) {
                            if (t.getName().equals(data[1])) {

                                Player player = new Player(data[2],
                                        Integer.parseInt(data[3]),
                                        Integer.parseInt(data[4]),
                                        Integer.parseInt(data[5]),
                                        Integer.parseInt(data[6]),
                                        Integer.parseInt(data[7])
                                );
                                t.addPlayer(player);
                                isTeamPresented = true;
                                break;
                            }
                        }
                        if (!isTeamPresented) {
                            throw new Exception(String.format("Team %s does not exist.", data[1]));
                        }
                        break;

                    case "Remove":
                        for (Team t : teams) {
                            if (t.getName().equals(data[1])) {
                                t.removePlayer(data[2]);
                                break;
                            }
                        }
                        break;

                    case "Rating":
                        for (Team t : teams) {
                            if (t.getName().equals(data[1])) {
                                System.out.println(String.format("%s - %.0f", t.getName(), t.getRating()));
                                break;
                            }
                        }
                        break;
                }

            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            input = scanner.nextLine();
        }
    }
}

